import { Component } from '@angular/core';

@Component({
  selector: 'app-my-cab-booking',
  templateUrl: './my-cab-booking.component.html',
  styleUrl: './my-cab-booking.component.scss'
})
export class MyCabBookingComponent {

}
