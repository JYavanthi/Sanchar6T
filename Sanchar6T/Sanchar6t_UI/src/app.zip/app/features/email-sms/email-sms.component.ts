import { Component } from '@angular/core';

@Component({
  selector: 'app-email-sms',
  templateUrl: './email-sms.component.html',
  styleUrl: './email-sms.component.scss'
})
export class EmailSmsComponent {

}
