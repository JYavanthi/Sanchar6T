import { Component } from '@angular/core';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrl: './cancel-ticket.component.scss'
})
export class CancelTicketComponent {

}
