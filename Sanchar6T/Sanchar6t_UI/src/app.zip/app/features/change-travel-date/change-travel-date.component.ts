import { Component } from '@angular/core';

@Component({
  selector: 'app-change-travel-date',
  templateUrl: './change-travel-date.component.html',
  styleUrl: './change-travel-date.component.scss'
})
export class ChangeTravelDateComponent {

}
