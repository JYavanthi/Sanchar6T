import { Component } from '@angular/core';

@Component({
  selector: 'app-show-my-ticket',
  templateUrl: './show-my-ticket.component.html',
  styleUrl: './show-my-ticket.component.scss'
})
export class ShowMyTicketComponent {

}
