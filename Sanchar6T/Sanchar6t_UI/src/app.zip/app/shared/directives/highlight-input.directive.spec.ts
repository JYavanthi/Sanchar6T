import { HighlightInputDirective } from './highlight-input.directive';

describe('HighlightInputDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightInputDirective();
    expect(directive).toBeTruthy();
  });
});
