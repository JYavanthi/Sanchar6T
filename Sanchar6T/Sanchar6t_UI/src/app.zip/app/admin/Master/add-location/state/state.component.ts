import { Component } from '@angular/core';

@Component({
  selector: 'app-state',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.scss','../add-location.component.scss']
})
export class StateComponent {

}
