import { Component } from '@angular/core';

@Component({
  selector: 'app-bus-dashboard',
  templateUrl: './bus-dashboard.component.html',
  styleUrl: './bus-dashboard.component.scss'
})
export class BusDashboardComponent {

}
