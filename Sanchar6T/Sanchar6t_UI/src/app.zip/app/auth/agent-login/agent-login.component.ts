import { Component } from '@angular/core';

@Component({
  selector: 'app-agent-login',
  templateUrl: './agent-login.component.html',
  styleUrl: './agent-login.component.scss'
})
export class AgentLoginComponent {

}
